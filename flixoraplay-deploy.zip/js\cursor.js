/* ============================================================
   FlixoraPlay — Custom Cursor + Loading System
   ============================================================ */

(function () {
  'use strict';

  // ── Elements ──────────────────────────────────────────────
  const dot  = document.createElement('div');
  const ring = document.createElement('div');
  const bar  = document.createElement('div');

  dot.className  = 'cursor-dot';
  ring.className = 'cursor-ring';
  bar.className  = 'loading-bar';

  document.body.appendChild(dot);
  document.body.appendChild(ring);
  document.body.appendChild(bar);

  // ── Position tracking ────────────────────────────────────
  let mouseX = 0, mouseY = 0;
  let ringX   = 0, ringY  = 0;
  let raf;

  document.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;

    // Dot follows immediately
    dot.style.left = mouseX + 'px';
    dot.style.top  = mouseY + 'px';
  });

  // Ring follows with smooth lag
  function animateRing() {
    ringX += (mouseX - ringX) * 0.14;
    ringY += (mouseY - ringY) * 0.14;
    ring.style.left = ringX + 'px';
    ring.style.top  = ringY + 'px';
    raf = requestAnimationFrame(animateRing);
  }
  animateRing();

  // ── Hover detection ──────────────────────────────────────
  const interactive = 'a, button, .btn, input, select, textarea, .comp-card, .entry-card, .tab-btn, .vote-btn, .modal-close, .hiw-step, [data-hover], label';

  function onEnterInteractive() {
    ring.classList.add('hovered');
  }
  function onLeaveInteractive() {
    ring.classList.remove('hovered');
  }

  document.addEventListener('mouseover', (e) => {
    if (e.target.closest(interactive)) onEnterInteractive();
  });
  document.addEventListener('mouseout', (e) => {
    if (e.target.closest(interactive)) onLeaveInteractive();
  });

  // ── Click effects ────────────────────────────────────────
  document.addEventListener('mousedown', (e) => {
    ring.classList.add('clicked');
    dot.classList.add('clicked');
  });

  document.addEventListener('mouseup', () => {
    ring.classList.remove('clicked');
    dot.classList.remove('clicked');
  });

  document.addEventListener('click', (e) => {
    // Ripple
    const ripple = document.createElement('div');
    ripple.className = 'click-ripple';
    ripple.style.left = e.clientX + 'px';
    ripple.style.top  = e.clientY + 'px';
    document.body.appendChild(ripple);
    ripple.addEventListener('animationend', () => ripple.remove());
  });

  // ── Hide when cursor leaves window ──────────────────────
  document.addEventListener('mouseleave', () => {
    dot.style.opacity  = '0';
    ring.style.opacity = '0';
  });
  document.addEventListener('mouseenter', () => {
    dot.style.opacity  = '1';
    ring.style.opacity = '1';
  });

  // ── Loading bar ──────────────────────────────────────────
  window.LoadingBar = {
    start() {
      bar.style.transition = 'width 0.3s ease, opacity 0.2s ease';
      bar.style.opacity = '1';
      bar.style.width   = '0%';
      requestAnimationFrame(() => {
        bar.style.width = '35%';
        setTimeout(() => { bar.style.width = '65%'; }, 200);
        setTimeout(() => { bar.style.width = '80%'; }, 500);
      });
    },
    advance() {
      bar.style.width = '92%';
    },
    finish() {
      bar.style.width = '100%';
      setTimeout(() => {
        bar.style.opacity = '0';
        setTimeout(() => { bar.style.width = '0%'; bar.style.opacity = '1'; }, 400);
      }, 350);
    },
    error() {
      bar.style.background = '#ef4444';
      bar.style.boxShadow  = '0 0 8px #ef4444';
      bar.style.width = '100%';
      setTimeout(() => {
        bar.style.opacity = '0';
        setTimeout(() => {
          bar.style.width = '0%';
          bar.style.opacity = '1';
          bar.style.background = '';
          bar.style.boxShadow = '';
        }, 400);
      }, 500);
    }
  };

  // Auto-trigger on page links
  document.addEventListener('click', (e) => {
    const link = e.target.closest('a[href]');
    if (!link) return;
    const href = link.getAttribute('href');
    if (!href || href.startsWith('#') || href.startsWith('http') || href.startsWith('mailto')) return;
    e.preventDefault();
    LoadingBar.start();
    setTimeout(() => { LoadingBar.advance(); }, 100);
    setTimeout(() => {
      LoadingBar.finish();
      setTimeout(() => { window.location.href = href; }, 150);
    }, 500);
  });

  // Trigger on page load
  document.addEventListener('DOMContentLoaded', () => {
    LoadingBar.start();
    setTimeout(() => LoadingBar.finish(), 400);
  });

})();

// FlixoraPlay - Version 3 - Core JS (localStorage-based data layer)

// ── Storage helpers ───────────────────────────────────────
const Store = {
  get(key, fallback = []) {
    try {
      const v = localStorage.getItem('flixora_' + key);
      return v ? JSON.parse(v) : fallback;
    } catch { return fallback; }
  },
  set(key, value) {
    localStorage.setItem('flixora_' + key, JSON.stringify(value));
  },
  // Seed demo data on first load
  seed() {
    if (Store.get('seeded', false)) return;

    const competitions = [
      {
        id: 'c1',
        title: 'Sci-Fi Visions 2025',
        theme: 'Sci-fi short under 60 seconds',
        description: 'Create a cinematic sci-fi AI-generated video in under 60 seconds. Think space, future cities, alien landscapes.',
        deadline: '2025-05-30',
        prize: '$500',
        judging: 'manual',
        maxDuration: 60,
        status: 'open',
        hostId: 'u_host1',
        hostName: 'Neon Studios',
        createdAt: '2025-04-01',
        entries: [],
        winners: {}
      },
      {
        id: 'c2',
        title: 'Nature Reimagined',
        theme: 'AI-rendered nature scenes',
        description: 'Show nature like never seen before using AI video generation tools. Forests, oceans, mountains — reimagined.',
        deadline: '2025-06-15',
        prize: '$300',
        judging: 'manual',
        maxDuration: 30,
        status: 'open',
        hostId: 'u_host2',
        hostName: 'EarthFrame Co.',
        createdAt: '2025-04-05',
        entries: [],
        winners: {}
      },
      {
        id: 'c3',
        title: 'Human Emotion Reel',
        theme: 'Emotion storytelling under 90s',
        description: 'Tell an emotional story using AI-generated visuals. No dialogue needed. Express through imagery.',
        deadline: '2025-04-20',
        prize: null,
        judging: 'manual',
        maxDuration: 15,
        status: 'judging',
        hostId: 'u_host1',
        hostName: 'Neon Studios',
        createdAt: '2025-03-20',
        entries: ['e1', 'e2', 'e3'],
        winners: { first: 'e1', second: 'e2', third: 'e3' }
      },
    ];

    const entries = [
      {
        id: 'e1',
        competitionId: 'c3',
        title: 'The Last Teardrop',
        description: 'An AI film depicting the final moments of memory fading away.',
        videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        creatorId: 'u_c1',
        creatorName: 'Arya Mehta',
        tools: ['Runway ML', 'Midjourney'],
        submittedAt: '2025-04-05',
        score: 92,
        votes: 47,
        rank: 1
      },
      {
        id: 'e2',
        competitionId: 'c3',
        title: 'Echoes of Childhood',
        description: 'Nostalgic memories visualized through dreamy AI landscapes.',
        videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        creatorId: 'u_c2',
        creatorName: 'Dev Patel',
        tools: ['Pika Labs', 'Stable Video'],
        submittedAt: '2025-04-06',
        score: 85,
        votes: 32,
        rank: 2
      },
      {
        id: 'e3',
        competitionId: 'c3',
        title: 'Joy in the Rain',
        description: 'Pure happiness rendered through AI-generated rain scenes.',
        videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        creatorId: 'u_c3',
        creatorName: 'Priya Singh',
        tools: ['Sora', 'Kling AI'],
        submittedAt: '2025-04-07',
        score: 78,
        votes: 26,
        rank: 3
      }
    ];

    const users = [
      { id: 'u_host1', name: 'Neon Studios', email: 'neon@studio.com' },
      { id: 'u_host2', name: 'EarthFrame Co.', email: 'earth@frame.com' },
      { id: 'u_c1', name: 'Arya Mehta', email: 'arya@creator.com' },
      { id: 'u_c2', name: 'Dev Patel', email: 'dev@creator.com' },
      { id: 'u_c3', name: 'Priya Singh', email: 'priya@creator.com' },
    ];

    Store.set('competitions', competitions);
    Store.set('entries', entries);
    Store.set('users', users);
    Store.set('seeded', true);
  }
};

// ── ID generator ──────────────────────────────────────────
function genId(prefix = 'id') {
  return prefix + '_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
}

// ── Toast notifications ───────────────────────────────────
function showToast(message, type = 'info', duration = 3500) {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const toastIcons = {
    success: '<svg data-lucide="check-circle" style="width:16px;height:16px;"></svg>',
    error:   '<svg data-lucide="alert-circle" style="width:16px;height:16px;"></svg>',
    info:    '<svg data-lucide="info" style="width:16px;height:16px;"></svg>',
  };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `${toastIcons[type] || toastIcons.info} <span>${message}</span>`;
  container.appendChild(toast);
  if (typeof lucide !== 'undefined') lucide.createIcons({ el: toast });
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(110%)';
    toast.style.transition = 'opacity 0.3s, transform 0.3s';
    setTimeout(() => toast.remove(), 320);
  }, duration);
}

// ── URL helpers ───────────────────────────────────────────
function getParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}
function navigate(url) { window.location.href = url; }

// ── Date helpers ──────────────────────────────────────────
function formatDate(dateStr) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}
function daysRemaining(deadlineStr) {
  const today = new Date();
  const deadline = new Date(deadlineStr);
  const diff = Math.ceil((deadline - today) / (1000 * 60 * 60 * 24));
  return diff;
}
function deadlinePercent(created, deadline) {
  const start = new Date(created);
  const end   = new Date(deadline);
  const now   = new Date();
  const total = end - start;
  const elapsed = now - start;
  return Math.min(100, Math.max(0, Math.round((elapsed / total) * 100)));
}

// ── Active nav link ───────────────────────────────────────
function setActiveNav() {
  const page = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(a => {
    const href = a.getAttribute('href');
    if (href === page || (page === '' && href === 'index.html')) {
      a.classList.add('active');
    }
  });
}

// ── Tab switcher ──────────────────────────────────────────
function initTabs() {
  document.querySelectorAll('.tabs').forEach(tabGroup => {
    const buttons = tabGroup.querySelectorAll('.tab-btn');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.tab;
        buttons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll(`.tab-panel[data-tab="${target}"]`).forEach(p => p.classList.add('active'));
        document.querySelectorAll(`.tab-panel:not([data-tab="${target}"])`).forEach(p => p.classList.remove('active'));
      });
    });
    // Activate first tab by default
    if (buttons.length > 0) buttons[0].click();
  });
}

// ── Nav scroll effect ─────────────────────────────────────
window.addEventListener('scroll', () => {
  const nav = document.querySelector('nav');
  if (nav) nav.classList.toggle('scrolled', window.scrollY > 10);
});

// ── Init on load ──────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  Store.seed();
  setActiveNav();
  initTabs();
});
